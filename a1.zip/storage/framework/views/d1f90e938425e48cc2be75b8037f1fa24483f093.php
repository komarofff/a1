<?php $__env->startSection('title', 'ForwarderOne-request page. Only desktop version'); ?>
<?php $__env->startSection('description', 'ForwarderOne-request page -description'); ?>
<?php $__env->startSection('og'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<!-- <script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script> -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<header class="header">
<img class="header__banner" src="<?php echo e(asset('/img/header/banner-check.png')); ?>" srcset="<?php echo e(asset('/img/header/banner-check@2x.png')); ?>">

    <?php echo $__env->make('layouts.partials.topmenu', ['menu'=> [
    ['link' => '#', 'title' => 'About Us'],
    ['link' => '#', 'title' => 'Pricing'],
    ['link' => '#', 'title' => 'FAQ']
    ]]
    , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="header__content request-header-content">
        <p class="header__content-text">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Habes, inquam, Cato, formam eorum, de quibus
            loquor praecepta dantur.
        </p>
        <p class="header__content-title">
            Reliable Amazon FBA
        </p>
        <p class="header__content-subtitle">
            Freight Forwarding
        </p>
    </div>

</header>
<main class=" grid main request">
    <section class="main__people-blocks padding-both-vertical">
       
        <div class="grid">

        <div class="accept__block_2_column">
                    <div class="accept-block">
                        <img class="accept-img" src="img/main/accept.png" srcset="img/main/accept@2x.png" >
                    </div>
                    <div>
                        <p class="h2">Your Requested <span class="red">#12758927</span></p>
                        <p class="h2">Was Successfully Accepted</p>
                        <p class="text">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Scio enim esse quosdam,
                            qui quavis lingua philosophari possint; Duo Reges: constructio interrete. Quos quidem tibi
                            studiose et diligenter tractandos magnopere censeo. At, si voluptas esset bonum,
                            desideraret.
                        </p><p class="text">    
                            Iam id ipsum absurdum, maximum malum neglegi. Quae cum dixisset paulumque institisset, Quid
                            est? An hoc usque quaque, aliter in vita?</p>
                    </div>

                </div>

        </div>
    </section>
</main>
<?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServer\domains\a1\resources\views/pages/accept.blade.php ENDPATH**/ ?>