<div class="grid header__topmenu">
<img class="header__logo" src="<?php echo e(asset('/img/header/LogoE3PL.png')); ?>"
                srcset="<?php echo e(asset('/img/header/LogoE3PL@2x.png')); ?>">
<nav class="header__topmenu-list">
        <ul>
            <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a class="header__topmenu-list_link" href="<?php echo e($item['link']); ?>"><?php echo e($item['title']); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </nav>
</div><?php /**PATH E:\OpenServer\domains\a1\resources\views/layouts/partials/topmenu.blade.php ENDPATH**/ ?>