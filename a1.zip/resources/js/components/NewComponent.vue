<template>
    <div class="main__people-blocks padding-both-vertical">
        <p class="h2">Testimonial Belt</p>
        <div class="grid">
            <div class="main__blocks ">
                <div class="main__people-block">
                    <img class="main__people-image" src="img/main/layer-34.jpg"
                        srcset="img/main/layer-34@2x.jpg">
                    <p class="h3">JOHN DOE</p>
                    <p class="small-text">
                        Deinde prima illa, quae in congressu solemus: Quid tu, inquit, huc? Sed tamen omne, quod de.
                    </p>
                </div>
                <div class="main__people-block ">
                    <img class="main__people-image" src="img/main/layer-36.jpg"
                        srcset="img/main/layer-36@2x.jpg">
                    <p class="h3">Jenelyn Doe</p>
                    <p class="small-text">
                        Deinde prima illa, quae in congressu solemus: Quid tu, inquit, huc? Sed tamen omne, quod de.
                    </p>
                </div>
                <div class="main__people-block">
                    <img class="main__people-image" src="img/main/layer-35.jpg"
                        srcset="img/main/layer-35@2x.jpg">
                    <p class="h3">Alex DOE</p>
                    <p class="small-text">
                        Deinde prima illa, quae in congressu solemus: Quid tu, inquit, huc? Sed tamen omne, quod de.
                    </p>
                </div>
            </div> 
        </div>
    </div>
</template>

<script>
    export default {
        mounted() {
            console.log('Component mounted.')
        }
    }
</script>
