<template>
    <div class="main__testimonials-slider ">
                <div>
                    <div class="main__testimonials-slider-block">
                        <p class="h3 white">Testimonials</p>
                        <p class="h2 white">What our members have to say...</p>
                        <img class="testimonials-small-image" src="/img/main/layer-43.jpg"
                            srcset="img/main/layer-43@2x.jpg">
                        <p class="big-text white">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Habes, inquam, Cato, formam eorum,
                            de quibus loquor, philosophorum. Ad eas enim res ab Epicuro praecepta dantur. Urgent tamen
                            et nihil remittunt. Graecum enim hunc versum nostis omnes-: Suavis laborum est praeteritorum
                            memoria.
                        </p>
                        <p class="star">
                            <span class="material-icons">star</span>
                            <span class="material-icons">star</span>
                            <span class="material-icons">star</span>
                            <span class="material-icons">star</span>
                            <span class="material-icons">star</span>
                        </p>
                        <p class="text white bottom-margin-none">Patrick losey, CEO</p>
                        <p class="smaller-text white">Rainingfire Interactive</p>
                    </div>
                </div>
                <div>
                    <div class="main__testimonials-slider-block">
                        <p class="h3 white">Testimonials</p>
                        <p class="h2 white">What our members have to say...</p>
                        <img class="testimonials-small-image" src="img/main/layer-43.jpg"
                            srcset="img/main/layer-43@2x.jpg">
                        <p class="big-text white">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Habes, inquam, Cato, formam eorum,
                            de quibus loquor, philosophorum. Ad eas enim res ab Epicuro praecepta dantur. Urgent tamen
                            et nihil remittunt. Graecum enim hunc versum nostis omnes-: Suavis laborum est praeteritorum
                            memoria.
                        </p>
                        <p class="star">
                            <span class="material-icons">star</span>
                            <span class="material-icons">star</span>
                            <span class="material-icons">star</span>
                            <span class="material-icons">star</span>
                            <span class="material-icons">star</span>
                        </p>
                        <p class="text white bottom-margin-none">Patrick losey, CEO</p>
                        <p class="smaller-text white">Rainingfire Interactive</p>
                    </div>
                </div>
                <div>
                    <div class="main__testimonials-slider-block">
                        <p class="h3 white">Testimonials</p>
                        <p class="h2 white">What our members have to say...</p>
                        <img class="testimonials-small-image" src="img/main/layer-43.jpg"
                            srcset="img/main/layer-43@2x.jpg">
                        <p class="big-text white">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Habes, inquam, Cato, formam eorum,
                            de quibus loquor, philosophorum. Ad eas enim res ab Epicuro praecepta dantur. Urgent tamen
                            et nihil remittunt. Graecum enim hunc versum nostis omnes-: Suavis laborum est praeteritorum
                            memoria.
                        </p>
                        <p class="star">
                            <span class="material-icons">star</span>
                            <span class="material-icons">star</span>
                            <span class="material-icons">star</span>
                            <span class="material-icons">star</span>
                            <span class="material-icons">star</span>
                        </p>
                        <p class="text white bottom-margin-none">Patrick losey, CEO</p>
                        <p class="smaller-text white">Rainingfire Interactive</p>
                    </div>
                </div>

            </div>
</template>

<script>
    export default {
       
    }
</script>
